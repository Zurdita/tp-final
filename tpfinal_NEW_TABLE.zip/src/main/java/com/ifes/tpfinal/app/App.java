package com.ifes.tpfinal.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import javax.jdo.JDOHelper;
import javax.jdo.PersistenceManagerFactory;

@SpringBootApplication(scanBasePackages = "com.ifes.tpfinal")
public class App {
    @Bean
    public PersistenceManagerFactory pmf() {
        return JDOHelper.getPersistenceManagerFactory("mysql");
    }
    public static void main(String[] args) {
        SpringApplication.run(App.class, args);
    }
}
